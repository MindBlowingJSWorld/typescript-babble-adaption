'use strict';

var build_config = require('./build.config.js');

var files = build_config.vendor_files.js;
files = files.concat(build_config.vendor_files.mocks);
files = files.concat(['src/**/*.js']);

module.exports = function (karma) {

  karma.set({

    /** 
     * From where to look for files, starting with the location of this file.
     */
    basePath: '../',

    /**
     * This is the list of file patterns to load into the browser during testing.
     */
    files: files,

    exclude: [
      'src/assets/**/*.js', 'src/app/**/*.mock.js'
    ],

    frameworks: [ 'jasmine' ],

    plugins: [
      'karma-jasmine',

      'karma-ie-launcher',
      'karma-chrome-launcher',
      'karma-firefox-launcher',

      'karma-junit-reporter',
      'karma-coverage'
    ],

    /**
     * How to report, by default.
     */
    reporters: 'progress',

    /**
     * On which port should the browser connect, on which port is the test runner
     * operating, and what is the URL path for the browser to use.
     */
    port: 9018,
    runnerPort: 9100,
    urlRoot: '/',

    /**
     * Disable file watching by default.
     */
    autoWatch: false,

    singleRun: true,

    /**
     * The list of browsers to launch to test on:
     * Chrome, ChromeCanary, Firefox, Opera, Safari, PhantomJS (remember to add respective dependency)
     *
     * Note that you can also use the executable name of the browser, like "chromium"
     * or "firefox", but that these vary based on your operating system.
     *
     * You may also leave this blank and manually navigate your browser to
     * http://localhost:9018/ when you're running tests. The window/tab can be left
     * open and the tests will automatically occur there during the build. This has
     * the aesthetic advantage of not launching a browser every time you save.
     */
    browsers: [
        'Chrome', 'IE'
    ],

    preprocessors: {
      // source files, that you wanna generate coverage for
      // do not include tests or libraries
      // (these files will be instrumented by Istanbul)
      'src/app/**/*.js': ['coverage']
    },

    // the default configuration
    junitReporter: {
      outputFile: 'reports/test-results.xml',
      suite: ''
    },

    coverageReporter: {
      reporters:[
        {type: 'html', dir:'reports/coverage/'}
      ]
    }

  });
};

