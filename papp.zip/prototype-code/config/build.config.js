/**
 * This file/module contains all configuration for the build process.
 */
module.exports = {
  /**
   * The `build_dir` folder is where our projects are compiled during
   * development and the `dist_dir` folder is where our app resides once it's
   * completely built. `docs_dir` contains generated JsDoc.
   */
  build_dir: '.tmp',
  dist_dir: 'dist',
  config_dir: 'config',

  /**
   * This is a collection of file patterns that refer to our app code (the
   * stuff in `src/`). These file paths are used in the configuration of
   * build tasks. `js` is all project javascript, less tests. `ctpl` contains
   * our reusable components' (`src/common`) template HTML files, while
   * `atpl` contains the same, but for our app's code. `html` is just our
   * main HTML file, `less` is our main stylesheet, and `unit` contains our
   * app's unit tests.
   */
  app_files: {
    js: [ 'src/**/*.js', '!src/**/*.spec.js', '!src/assets/**/*.js', '!<%= app_files.mocks %>',  '!<%= app_files.simulated %>'],
    mocks: [ 'src/**/*.mock.js'],
    simulated: ['src/**/exclude__/**/*.js'],
    tpl: [ 'src/app/**/*.tpl.html' ]
  },

  /**
   * This is a collection of files used during testing only.
   */
  test_files: {
    js: [
      'node_modules/angular-mocks/angular-mocks.js'
    ],
    html: [ 'test/**/*.html']
  },

  /**
   * This is the same as `app_files`, except it contains patterns that
   * reference vendor code (`vendor/`) that we need to place into the build
   * process somewhere. While the `app_files` property ensures all
   * standardized files are collected for compilation, it is the user's job
   * to ensure non-standardized (i.e. vendor-related) files are handled
   * appropriately in `vendor_files.js`.
   *
   * The `vendor_files.js` property holds files to be automatically
   * concatenated and minified with our project source files.
   *
   * The `vendor_files.css` property holds any CSS files to be automatically
   * included in our app.
   *
   * The `vendor_files.assets` property holds any assets to be copied along
   * with our app's assets. This structure is flattened, so it is not
   * recommended that you use wildcards.
   */
  vendor_files: {
    js: [
      'node_modules/jquery/dist/jquery.min.js',
      'node_modules/angular/angular.js',
      'node_modules/angular-cookies/angular-cookies.min.js',
      'node_modules/angular-ui-router/release/angular-ui-router.js',
      'node_modules/angular-touch/angular-touch.min.js',
      'node_modules/angular-resource/angular-resource.js',
      'node_modules/lodash/index.js',
      'node_modules/d3/d3.js',
      'node_modules/topojson/topojson.js',
      'node_modules/nbo-core-front/nbo-core.js',
      'node_modules/moment/moment.js',    

      // localization
      'node_modules/rbo-angular-localization/rbo-localization.min.js',
      'node_modules/rbo-angular-tracker/dist/webtrends.js',
      'node_modules/rbo-angular-tracker/dist/tracker.min.js',
      
      'node_modules/rbo-customization/rbo-customization.js',
      'node_modules/ng-dialog/js/ngDialog.js',
      'node_modules/nbo-ui-elements/nboUiElements.js',
      'node_modules/angular-cookie/angular-cookie.js',
      'node_modules/rbo-authn/rbo-authn.js',
      'node_modules/nbo-savings/nbo-savings.js'
    ],
    css: [
      'node_modules/nbo-core-front/nbo-core.css',
      'node_modules/nbo-savings/nbo-savings.css',
      'node_modules/rbo-authn/rbo-authn.css',
      'node_modules/nbo-ui-elements/nboUiElements.css'
    ],

    assets: [
    ],
    mocks: ['node_modules/angular-mocks/angular-mocks.js',
            'node_modules/nbo-core-front/nbo-core.mocks.js',
            'node_modules/rbo-authn/rbo-authn.mocks.js',
            'node_modules/nbo-savings/nbo-savings.mocks.js']
  },

  /**
   * This is a collection of files used during e2e testing only.
   */
  e2e_test_files: {
    js: [ 'test/**/*.js', 'test/**/*.spec.js'],
    mock: ['vendor/angular-mocks/angular-mocks.js'],
    html: [ 'test/**/*.html']
  }
};
