define(['angularAMD'], function (angularAMD) {

    'use strict';

    var Resolver = function ($rootScope, $q, $injector) {

        var getModule = function (path, name, method, params) {
            var deferred = $q.defer();

            require([path], function () {
                $rootScope.$apply(function () {
                    var injectedService = $injector.get(name);

                    if (method) {
                        injectedService[method].apply(null, params).then(function(response) {
                            deferred.resolve(response);
                        });
                    } else {
                        deferred.resolve(injectedService);
                    }
                });
            });

            return deferred.promise;
        };

        var getModules = function (modules) {
            var deferred = $q.defer();

            require(modules, function () {
                $rootScope.$apply(function () {
                    deferred.resolve(true);
                });
            });

            return deferred.promise;
        };

        var get = function () {
            if (angular.isArray(arguments[0])) {
                return getModules(arguments[0]);
            } else {
                return getModule.apply(null, arguments);
            }
        };

        return {
            get: get
        };

    };

    angularAMD.service('Resolver', Resolver);
    Resolver.$inject = ['$rootScope', '$q', '$injector'];
});
