define(['angularAMD'], function (angularAMD) {

    'use strict';

    var User = function ($cookies) {
        var user;

        var prepare = function (userData) {
            var output;

            output = userData;

            return output;
        };

        var set = function (userData) {
            user = userData ? prepare(userData) : null;
        };

        var get = function () {
            return user;
        };

        var isSignedIn = function () {
            return !!user;
        };

        var init = function () {
            user = prepare($cookies.getObject('User'));
        };

        var isPrivate = function () {
            return user.type === 'PRIVATE';
        };

        var signOut = function () {
            $cookies.remove('User');
            set(null);
        };

        init();

        return {
            set: set,
            get: get,
            signOut: signOut,
            isSignedIn: isSignedIn,
            isPrivate: isPrivate
        };
    };

    angularAMD.service('User', User);
    User.$injext = ["$cookies"];
});
