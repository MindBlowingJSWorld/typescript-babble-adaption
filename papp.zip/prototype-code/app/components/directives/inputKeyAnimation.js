define(['angularAMD'], function (app) {

    'use strict';

    var inputKeyAnimation = function () {
        var link = function (scope, el, attr) {
            var $el = $(el),
                $nextEl = $el.next('input'),
                $prevEl = $el.prev('input'),
                classNameAttr = attr.inputKeyAnimation,
                className = (angular.isString(classNameAttr) && classNameAttr.length) ? classNameAttr : 'inputAnimate';

            $el.bind('keydown', function () {
                $el.addClass(className);

                setTimeout(function () {
                    $el.removeClass(className);
                }, 400);

            });

            $el.bind('keyup', function (key) {
                var valueLength = this.value.length;

                if (valueLength) {
                    $nextEl.focus();
                }
                if (!valueLength && key.keyCode === 8) {
                    $prevEl.focus();
                    $prevEl.value = '';
                }
            });
        };

        return {
            link: link,
            restrict: 'A'
        };

    };

    app.directive('inputKeyAnimation', inputKeyAnimation);
});
