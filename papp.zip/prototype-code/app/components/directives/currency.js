define(['app', 'CustomCurrency'], function (app) {

    'use strict';

    var currency = function ($filter) {
        var link = function (scope, el) {
            var formattedValue = $filter('customCurrency')(scope.value);

            if (scope.value > 0) {
                el.addClass('money-in');
            }
            el.html(formattedValue);
        };

        return {
            link: link,
            restrict: 'A',
            scope: {
                value: "=currency"
            }
        };
    };

    app.directive('currency', currency);
    currency.$inject = ['$filter'];
});
