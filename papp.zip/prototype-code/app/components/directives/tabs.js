define(['angularAMD'], function (angularAMD) {

    'use strict';

    var tabs = function () {
        var link = function (scope) {
            var setActive = function (index) {
                scope.elements.map(function (v, i) {
                    v.active = (i === index);
                });
            };

            scope.tabChange = function (e, i, key) {
                e.preventDefault();

                setActive(i);
                (scope.callback || angular.noop)(key);
            };
        };

        return {
            link: link,
            restrict: 'E',
            replace: true,
            template: '' +
                    '<ul>' +
                        '<li ng-repeat="el in elements track by $index" ng-class="{active: el.active}"><a href="#" ng-click="tabChange($event, $index, el.key)">{{el.name}}</a></li>' +
                    '</ul>',
            scope: {
                elements: '=',
                callback: '='
            }
        };
    };

    angularAMD.directive('tabs', tabs);
    tabs.$inject = ['$filter'];
});
