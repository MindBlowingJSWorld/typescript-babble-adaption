define(['angularAMD'], function (angularAMD) {
    'use strict';

    var preventDefault = function () {
        var link = function (scope, el) {
            var $el = $(el);

            $el.on('click', function(e){
               e.preventDefault();
            });

        };

        var directive = {
            link: link,
            restrict: 'A'
        };

        return directive;
    };

    angularAMD.directive('preventDefault', preventDefault);
});
