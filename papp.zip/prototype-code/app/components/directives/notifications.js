define(['angularAMD', 'velocity'], function (angularAMD) {
    'use strict';

    var notifications = function() {
        var link = function(scope, el) {
            var $el = $(el),
                item = $el.find('.notification'),
                timerItem = $el.find('.timer' ),
                offspring = $el.find('.offspring' ),
                minH = '48px',
                $close = $(el).find('.close');

            var hide = function(e) {
                var content = item.find('.notifications-content'),
                    offspring = $el.find('.offspring'),
                    bellWrap = $(document).find('.user-notification'),
                    bell = bellWrap.find('.icon-notification'),
                    notificationIcon = $(document).find('#notifications'),
                    notificationIconOffset = notificationIcon.offset().left;

                if (e) {
                    e.preventDefault();
                }

                item
                    .velocity({
                        opacity: '0'
                    },{duration: 250, complete: function(){
                        item.hide();

                        offspring
                            .removeClass('open')
                            .velocity({
                                top: '6px',
                                height: '36px',
                                width: '36px',
                                left: notificationIconOffset - 10 + 'px',
                                borderRadius: '24px'
                                },{duration: 300, complete: function(){
                                    offspring
                                        .velocity({
                                            height: '0',
                                            width: '0',
                                            top: '48px',
                                            left: notificationIconOffset - 10 + 24 + 'px',
                                            opacity: '0'
                                        },{duration: 50, complete: function(){

                                            bellWrap.removeClass('empty' ).addClass('has-message').find('.notification-count').text('1');
                                            bell.addClass('swing');
                                            $el.removeClass('active');

                                        }}, "easeInSine");

                                    $el
                                        .velocity({
                                            minHeight: 0
                                        },{ duration: 200}, "easeInSine");
                                }}, "easeInSine");
                    }});

                content.velocity({
                    opacity: '0'
                },{ duration: 200});
            };

            var show = function(e, message) {
                var talkWithUsOffset = $(document).find('#talk-with-us').offset().left;

                timerItem
                    .css({'display': 'block'})
                    .text(5);


                item
                    .velocity({
                        opacity: '1'
                    });

                item.find('.notifications-content')
                    .velocity({
                        opacity: '1'
                    });

                var content = item.find('.notifications-content');

                //Notification close timer
                var notificationTimer = function () {
                    var i = 5,  // timer offset
                        interval = setInterval(function () {
                            i--;
                            timerItem.html(i);
                            if (i === 0) {
                                clearInterval(interval);
                                timerItem.html(i).fadeOut('slow');
                                hide();
                            }
                        }, 1000);
                };

                scope.message = message;

                offspring.css({'left': talkWithUsOffset + 37 + 'px'});

                $el.velocity({
                    minHeight: minH
                }, {duration: 500}, "easeInSine");

                offspring.velocity({
                    top: '6px',
                    left: talkWithUsOffset + 37 - 18 + 'px',
                    opacity: '1',
                    width: '36px',
                    height: '36px'
                }, {
                    duration: 250, complete: function () {
                        offspring.velocity({
                            width: '100%',
                            height: '48px',
                            left: '0',
                            top: '0',
                            borderRadius: '0'
                        }, {
                            duration: 300, complete: function () {
                                offspring.addClass('open');
                                notificationTimer();
                            }
                        }, "easeInSine");
                    }
                }, "easeInSine");

                setTimeout(function () {
                    item.fadeIn();
                }, 500);
            };

            $close.on('click', hide);
            scope.$on('$showNotification', show);
        };

        var directive = {
            link: link,
            template: '' +
                '<div class="notification-wrapper">' +
                    '<span class="timer"></span>' +
                    '<span class="offspring"></span>' +
                    '<i class="close" title="Close"></i>' +
                    '<div class="row">' +
                        '<div class="small-12 columns">' +
                            '<div class="notification">' +
                                '<span class="notifications-content" ng-bind-html="message"></span>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>',
            restrict: 'E',
            replace: true
        };

        return directive;
    };

    angularAMD.directive('notifications', notifications);
    notifications.$inject = [];
});

