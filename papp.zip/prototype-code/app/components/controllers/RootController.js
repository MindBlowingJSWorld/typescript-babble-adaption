define(['app', 'Authentication', 'velocity'], function (app) {
    'use strict';

    app.controller('RootController', ['$rootScope', '$state', 'AuthenticationService', function ($rootScope, $state, AuthenticationService) {

        var previousState = null,
            hasPreviousState = false;

        $rootScope.pageCssClass = '';
        $rootScope.headerCssClass = '';

        $rootScope.clearClasses = function () {
            $rootScope.pageCssClass = '';
            $rootScope.headerCssClass = '';
        };

        $rootScope.$on('$stateChangeSuccess', function (event, to, toParams, from) {
            $rootScope.previousState = from.name;
            $rootScope.currentState = to.name;
            $rootScope.hasPreviousState = false;

            previousState = $rootScope.previousState;
            hasPreviousState = !!previousState;
            $rootScope.hasPreviousState = hasPreviousState;

        });

        $rootScope.backToPreviousState = function (event) {
            event.preventDefault();
            event.stopPropagation();

            if (hasPreviousState) {
                $state.go($rootScope.previousState);
            }
        };

        $rootScope.logOut = function (event) {

            event.preventDefault();
            event.stopPropagation();

            AuthenticationService.logOut(function () {
                $state.go('authorization.loggedOut');
            });
        };


        var self = this;
        this.dataPattern = function () {
            $('[data-pattern]').each(function(){
                var dataValue = $(this).attr('data-pattern');
                $(this).css('width' , dataValue + "%");
            });
        };
        self.dataPattern();


    }]);

});
