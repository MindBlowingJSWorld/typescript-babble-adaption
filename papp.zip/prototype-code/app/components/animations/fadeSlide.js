define(['angularAMD'], function (angularAMD) {
    'use strict';

    var DURATION = 400;

    angularAMD.animation('.fade-slide', ['$timeout', function($timeout) {
        return {
            enter: function(el, doneFn) {
                var $el = $(el),
                    $parent = $el.parent(),
                    height = $el.outerHeight();

                $el.hide();

                if (height) {
                    $timeout(function () {
                        $parent.animate({
                            height: height + 'px'
                        }, DURATION);

                        $el.fadeIn(DURATION, doneFn);
                    });
                } else {
                    $el.show();
                    doneFn();
                }
            },

            leave: function(el, doneFn) {
                var $el = $(el),
                    $parent = $el.parent();

                $parent.height($el.outerHeight() + 'px');

                $el.hide();
                doneFn();
            }
        };
    }]);
});