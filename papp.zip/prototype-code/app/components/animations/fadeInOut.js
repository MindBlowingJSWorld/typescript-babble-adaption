define(['angularAMD'], function (angularAMD) {
    'use strict';

    var DURATION = 400;

    var elHeight = function($el) {
        return $el.outerHeight() + 'px';
    };

    angularAMD.animation('.fade-in-out', ['$timeout', function($timeout) {
        return {
            enter: function(el, doneFn) {
                var $el = $(el),
                    $parent = $el.parent();

                var setParentHeight = function() {
                    $parent.animate({
                        height: elHeight($el)
                    }, DURATION);
                };

                $el.hide();

                $timeout(function() {
                    setParentHeight();
                    $el.fadeIn(DURATION, doneFn);
                });

                $el.on('resize', setParentHeight);
            },

            leave: function(el, doneFn) {
                var $el = $(el),
                    $parent = $el.parent();

                $parent.height(elHeight($el));
                $el.off('resize');
                $el.fadeOut(DURATION, function() {
                    doneFn();
                });
            }
        };
    }]);
});