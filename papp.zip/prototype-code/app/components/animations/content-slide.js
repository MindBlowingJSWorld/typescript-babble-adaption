define(['angularAMD', 'jquery-resize'], function (angularAMD) {
    'use strict';

    angularAMD
        .animation('.content-slide', ['$timeout', function() {
            return {
                enter: function(el, doneFn) {
                    var $el = $(el),
                        $parent = $el.parent();

                    var setHeight = function() {
                        var h  = $el.outerHeight(true);
                        if (h) {
                            $parent.height(h + 1);
                        }
                    };

                    setHeight();
                    $el.on('resize', setHeight);
                    $el.addClass('enter');
                    $el.onCSSTransitionEnd(doneFn);
                },

                leave: function(el, doneFn) {
                    var $el = $(el);

                    $el.addClass('leave');
                    $el.off('resize');
                    $el.onCSSTransitionEnd(doneFn);
                }
            };
        }]);
});
