define(['angularAMD'], function (angularAMD) {
    'use strict';

    var DURATION = 300;

    angularAMD.animation('.accordion', [function() {
        return {
            enter: function(el, doneFn) {
                $(el).slideDown(DURATION, doneFn);
            },

            leave: function(el, doneFn) {
                $(el).slideUp(DURATION, doneFn);
            }
        };
    }]);
});
