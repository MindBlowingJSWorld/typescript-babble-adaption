define(['angularAMD'], function (angularAMD) {
    'use strict';

    var DURATION = 400;

    var elHeight = function($el) {
         return $el.outerHeight() + 'px';
    };

    angularAMD.animation('.fade', ['$timeout', function($timeout) {
        return {
            enter: function(el, doneFn) {
                var $el = $(el),
                    $parent = $el.parent();

                $el.hide();

                $timeout(function() {
                    $parent.animate({
                        height: elHeight($el)
                    }, DURATION);
                    $el.fadeIn(DURATION, doneFn);
                });
            },

            leave: function(el, doneFn) {
                var $el = $(el),
                    $parent = $el.parent();

                $parent.height(elHeight($el));
                $el.hide();
                doneFn();
            }
        };
    }]);
});
