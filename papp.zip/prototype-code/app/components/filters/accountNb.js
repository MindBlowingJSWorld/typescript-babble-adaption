define(['angularAMD'], function (angularAMD) {

    'use strict';

    var toShort = function (nb) {
        if (!nb) return -1;
        return nb.substr(0, 2) + ' ... ' + nb.substr(-4);
    };

    var accountNb = function () {
        return function (nb, short) {
            if (short) {
                return toShort(nb);
            } else {
                return nb;
            }
        };
    };

    angularAMD.filter('accountNb', accountNb);
});
