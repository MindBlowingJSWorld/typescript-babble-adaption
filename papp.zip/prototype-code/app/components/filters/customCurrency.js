define(['angularAMD'], function (angularAMD) {

    'use strict';

    angularAMD.filter('customCurrency', function () {
        return function (value) {
            var textSplitted,
                resultText;

            var text = value || 0;
            text = text.toString().replace(',', '.').replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1 ");
            textSplitted =  text.indexOf('.') !== -1 ? text.split('.') : text.split();
            resultText = ['<b>', textSplitted[0], '</b>,', textSplitted[1] ? textSplitted[1] : '00'].join('');

            return resultText;
        };
    });

});
