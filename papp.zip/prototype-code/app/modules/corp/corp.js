define(['angularAMD'], function (angularAMD) {
    'use strict';

    angular
        .module('app.corp', [])
        .config(['$stateProvider', function ($stateProvider) {

            $stateProvider
                .state('root.corp', {
                    url: '/corp',
                    abstract: true
                })
                .state('root.corp.dashboard', {
                    url: '/dashboard',
                    views: {
                        'main@root': angularAMD.route({
                            templateUrl: Path.view('dashboard', 'corp'),
                            controller: 'CorpDashboardController',
                            controllerAs: 'vm',
                            controllerUrl: Path.controller('CorpDashboardController', 'corp')
                        }),
                        'messages@root.corp.dashboard': angularAMD.route({
                            templateUrl: Path.view('messages', 'check-and-pay'),
                            controller: 'CorpMessagesController',
                            controllerUrl: Path.controller('CorpMessagesController', 'corp')
                        })
                    },
                    resolve: {
                        MessagesList: ['Resolver', function (Resolver) {
                            return Resolver.get(Path.service('Messages', 'check-and-pay'), 'Messages', 'get');
                        }],
                        accountsList: ['Resolver', function(Resolver) {
                            return Resolver.get(Path.service('Products', 'check-and-pay'), 'Products', 'getCorpList');
                        }]
                    }
                });

        }]);

});
