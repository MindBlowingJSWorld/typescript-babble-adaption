define(['app'], function (app) {
    'use strict';

    var UserInfo = function($scope, User) {
        $scope.user =  User.get();
    };

    app.controller('UserInfoController', UserInfo);
    UserInfo.$inject = ['$scope', 'User'];
});
