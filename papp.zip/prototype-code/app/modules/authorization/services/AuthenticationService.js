define(['angularAMD'], function (angularAMD) {
    'use strict';

    angularAMD.service('AuthenticationService', ['$rootScope', '$http', '$q', '$log', '$cookies', 'User', function ($rootScope, $http, $q, $log, $cookies, User) {

        var prepareUser = function(user, obj) {
            var output = {
                user: user,
                step: 2
            };

            if (obj) {
                angular.extend(output, obj);
            }

            output.user.pin = [];

            return output;
        };

        var getUsers = function() {
            return $http.get(Path.fixture('users'));
        };

        var step1 = function(cmd) {
            var deferred = $q.defer();
            getUsers().then(function(json) {
                var user = findUser(json.data.users, cmd.user);

                if(user) {
                    deferred.resolve(prepareUser(user));
                } else {
                    deferred.resolve(getFakeUser());
                }
            });
            return deferred.promise;
        };

        var drawArrayElement = function(arr) {
            return arr
                .sort(function() {
                    return Math.random() - 0.5;
                })
                .slice(0, 1)[0];
        };

        var getFakeUser = function() {
            var deferred = $q.defer();

            $http.get(Path.fixture('fakeUsers')).then(function(json) {
                var user = drawArrayElement(json.data.fakeUsers);
                deferred.resolve(prepareUser(user));
            });
            return deferred.promise;
        };

        var step2 = function(cmd) {
            var deferred = $q.defer();

            getUsers().then(function(json) {
               var validUser = findUser(json.data.users, cmd.user, true);

                if (validUser) {
                    $cookies.putObject('User', validUser);
                    User.set(validUser);

                    $log.info('AUTHENTICATION SUCCESSFUL: Logged in user\n', validUser);
                    deferred.resolve(prepareUser(validUser, {success: true}));

                } else {
                    deferred.resolve(prepareUser(cmd.user, {error: true}));

                }
            });
            return deferred.promise;

        };

        var findUser = function(users, searched, validate) {
            var output = null;
            users.forEach(function(user) {
                if (user.login === searched.login) {
                    if(!validate || (validate && user.pin === searched.pin.join(''))) {
                        output = user;
                    }
                }
            });

            return output;
        };

        return {
            signIn: function(cmd) {
                if (cmd.step === 1) {
                    return step1(cmd);
                } else {
                    return step2(cmd);
                }
            },

            logOut: function (callback) {
                if (User.isSignedIn()) {
                    User.signOut();

                    (callback || angular.noop)();
                }
            }
        };

    }]);
});
