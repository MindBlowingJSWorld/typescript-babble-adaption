define(['angularAMD'], function (angularAMD) {
    'use strict';

    var moduleName = 'authorization';

    angular

        .module('app.authorization', [])

        .config(['$stateProvider', function ($stateProvider) {

            $stateProvider
                .state('authorization.logIn', {
                    url: '/log-in',
                    views: {
                        'logInOut@authorization': angularAMD.route({
                            templateUrl: Path.view('authorization', moduleName),
                            controller: 'AuthorizationController',
                            controllerUrl: Path.controller('AuthorizationController', moduleName)
                        }),
                        'log-in@authorization.logIn': angularAMD.route({
                            templateUrl: Path.view('log-in', moduleName),
                            controller: 'LogInController',
                            controllerUrl: Path.controller('LogInController', moduleName)
                        }),
                        'authorization-slider@authorization': angularAMD.route({
                            templateUrl: Path.view('authorization-slider', moduleName),
                            controller: 'AuthorizationSliderController',
                            controllerUrl: Path.controller('AuthorizationSliderController', moduleName)
                        })
                    }
                })
                .state('authorization.loggedOut', {
                    url: '/logged-out',
                    views: {
                        'logInOut@authorization': angularAMD.route({
                            templateUrl: Path.view('authorization', moduleName),
                            controller: 'AuthorizationController',
                            controllerUrl: Path.controller('AuthorizationController', moduleName)
                        }),
                        'logged-out@authorization.loggedOut': angularAMD.route({
                            templateUrl: Path.view('logged-out', moduleName),
                            controller: 'LoggedOutController',
                            controllerUrl: Path.controller('LoggedOutController', moduleName)
                        }),
                        'logout-bg@authorization': angularAMD.route({
                            templateUrl: Path.view('logout-bg', moduleName),
                            controller: 'LoggedOutBackgroundController',
                            controllerUrl: Path.controller('LoggedOutBackgroundController', moduleName)
                        })
                    }
                });

        }])

        .run(function () {
            $('#authorization-page').removeClass('loading');
        });

});
