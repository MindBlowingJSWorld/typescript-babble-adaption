define(['app', 'modules/authorization/directives/AuthorizationSlider'], function (app) {

    'use strict';

    app.controller('AuthorizationSliderController', ['$scope', function ($scope) {

        $scope.items = [{
            src: 'assets/img/slider/slider-img-2.jpg',
            content: 'Entire bank can fit into your pocket. Enjoy access to your account from anywhere',
            link: 'http://wp.pl/',
            buttonTitle: 'more'
        }, {
            src: 'assets/img/slider/slider-img-1.jpg',
            content: 'Feel safe wherever you are with Nordea Gold travel insurance',
            link: 'http://google.com/',
            buttonTitle: 'read more'
        }, {
            src: 'assets/img/slider/slider-img-3.jpg',
            content: 'Open an account now and receive 300,00 kr bonus!',
            link: 'http://facebook.com/',
            buttonTitle: 'read even more'
        }];

    }]);

});
