define(['app'], function (app) {

    'use strict';

    app.controller('LoggedOutBackgroundController', ['$scope', function ($scope) {
        var self = this;

        $scope.click = function () {
            console.log('click', $scope);
        };

        this.dataPattern = function () {
            console.log('LoggedOutBackgroundControl');
        };
        self.dataPattern();

    }]);

});
