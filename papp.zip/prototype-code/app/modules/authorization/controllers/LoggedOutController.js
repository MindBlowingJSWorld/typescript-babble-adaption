define(['app'], function (app) {

    'use strict';

    app.controller('LoggedOutController', ['$scope', '$state', function ($scope, $state) {

        $scope.logBackIn = function () {
            $state.go('authorization.logIn');
        };

    }]);

});
