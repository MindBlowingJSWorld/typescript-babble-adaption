define(['app', 'Authentication', 'velocity', 'components/directives/inputKeyAnimation', 'modules/authorization/directives/inputFocus'], function (app) {
    'use strict';

    app.controller('LogInController', ['$scope', '$state', 'AuthenticationService', 'User', function ($scope, $state, AuthenticationService, User) {
        var defaultCommand = {
            user: {
                login: null,
                pin: []
            },
            step: 1
        };

        var clearCommand = function() {
            $scope.command = angular.copy(defaultCommand);
        };

        clearCommand();

        $scope.form = {};

        $scope.loading = false;

        $scope.user = {
            login: null,
            pin: []
        };

        $scope.back = clearCommand;

        $scope.logIn = function(e) {
            e.preventDefault();

            if (!$scope.form.logInForm.$invalid) {
                $scope.loading = true;


                setTimeout(function(){
                    AuthenticationService.signIn($scope.command).then(function(resp) {
                        if (resp.success) {
                            endAnimation();
                        } else {
                            $scope.command = resp;
                        }

                        $scope.loading = false;
                    });

                },1500);
            }
        };

        var endAnimation = function() {
            var authorizatonBox = $('.authorization-box'),
                authorizatonBoxAnimParams1 = {
                    height: '22rem'
                },
                authorizatonBoxAnimParams2 = {
                    borderRadius: '50%'
                },
                authorizatonBoxAnimParams3 = {
                    translateX: '0',
                    left: '-25vw',
                    top: '-25vw',
                    width: '150vw',
                    height: '150vw'

                },

                form = $('.authorization-box-inner'),
                formAnimParams1 = {
                    opacity: '0'
                },

                moreActions = authorizatonBox.next('.authorization-additional-actions'),
                moreActionsAnimParams1 = {
                    opacity: '0'
                },

                outerSection = authorizatonBox.closest('#logInOut-view'),
                outerSectionAnimParams = {
                    left: '0',
                    top: '0',
                    width: '100vw',
                    height: '100vw',
                    borderRadius: '0'
                };
            form.velocity(formAnimParams1, {
                duration: 150,
                complete: function () {
                    moreActions.velocity(moreActionsAnimParams1);
                    authorizatonBox.velocity(authorizatonBoxAnimParams1, {
                        duration: 200,
                        complete: function () {
                            authorizatonBox.velocity(authorizatonBoxAnimParams2, {
                                duration: 200,
                                complete: function () {
                                    outerSection.velocity(outerSectionAnimParams);
                                    authorizatonBox.velocity(authorizatonBoxAnimParams3, {
                                        duration: 400,
                                        complete: function () {
                                            var path = User.isPrivate() ? 'root.checkAndPay.overview' : 'root.checkAndPay.overview';
                                            $state.go(path);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        };

    }]);

});



