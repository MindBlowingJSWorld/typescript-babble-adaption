define(['app'], function (app) {

    'use strict';

    app.controller('AuthorizationController', ['$scope', function ($scope) {

        $scope.click = function () {

        };

        $scope.b = function () {
            $('.overlay').removeClass('open');
        };

    }]);
});
