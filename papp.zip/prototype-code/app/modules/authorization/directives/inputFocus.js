define(['app'], function (app) {
    'use strict';

    var inputFocus = function() {
        var link = function(scope, el) {
            var $el = $(el);

            setTimeout(function(){
                $el.focus();
            }, 100);
        };

        var directive = {
            link: link,
            restrict: 'A'
        };

        return directive;
    };

    app.directive('inputFocus', inputFocus);
});
