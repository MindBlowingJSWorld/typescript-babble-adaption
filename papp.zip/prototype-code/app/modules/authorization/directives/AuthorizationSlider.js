define(['angularAMD','modernizr'],function (angularAMD) {

    'use strict';

    angularAMD.directive('swiperCarousel',['$timeout',function ($timeout) {
        return {
            restrict: 'E',
            transclude: false,
            link: function (scope) {
                scope.initCarousel = function () {

                    var support = { animations : Modernizr.cssanimations },
                        animEndEventNames = {
                            'WebkitAnimation' : 'webkitAnimationEnd',
                            'OAnimation' : 'oAnimationEnd',
                            'msAnimation' : 'MSAnimationEnd',
                            'animation' : 'animationend'
                        },
                        animEndEventName = animEndEventNames[ Modernizr.prefixed( 'animation' ) ],
                        component = $( '#component' ),
                        items = component.find( 'ul.itemwrap' ).children(),
                        current = 0,
                        itemsCount = items.length,
                        nav = component.find( 'nav' ),
                        isAnimating = false;


                    function navigate( next,controller ) {
                        if( isAnimating ) return false;
                        isAnimating = true;
                        var cntAnims = 0;
                        var dir = 'next';

                        var currentItem = items[ current ];

                        if ( controller == 'auto'){
                            dir = 'next';
                        }
                        else if ( controller == 'manual'){
                            if (next > current ){
                                dir = 'next';
                            }

                            else {
                                dir = 'prev';
                            }
                        }
                        if( dir === 'next' ) {
                            current = current < itemsCount - 1 ? parseFloat(current) + 1 : 0;
                        }
                        else if( dir === 'prev' ) {
                            current = current > 0 ? parseFloat(current) - 1 : itemsCount - 1;
                        }
                        if (controller =='manual'){
                            current = next
                        }
                        var nextItem = items[ current ];

                        var onEndAnimationCurrentItem = function() {
                            $(this).off( animEndEventName, onEndAnimationCurrentItem );
                            $(this).removeClass('current' );
                            $(this).removeClass( dir === 'next' ? 'navOutNext' : 'navOutPrev')
                            ++cntAnims;
                            if( cntAnims === 2 ) {
                                isAnimating = false;
                            }
                        }

                        var onEndAnimationNextItem = function() {
                            $(this).off( animEndEventName, onEndAnimationNextItem );
                            $(this).addClass( 'current' );
                            $(this).removeClass( dir === 'next' ? 'navInNext' : 'navInPrev' );
                            ++cntAnims;
                            if( cntAnims === 2 ) {
                                isAnimating = false;
                            }
                        }

                        if( support.animations ) {
                            $(currentItem).on( animEndEventName, onEndAnimationCurrentItem );
                            $(nextItem).on( animEndEventName, onEndAnimationNextItem );
                        }
                        else {
                            onEndAnimationCurrentItem();
                            onEndAnimationNextItem();
                        }

                        $(currentItem).addClass(  dir === 'next' ? 'navOutNext' : 'navOutPrev' );
                        $(nextItem).addClass(  dir === 'next' ? 'navInNext' : 'navInPrev' );

                        nav.find('[data-swith]').removeClass('active')
                        nav.find('[data-swith='+current+']').addClass('active')
                    }

                    var  intervalID = setInterval(function(){
                        navigate('1','auto')
                    }, 5000)

                    function pagination() {
                        var i = 0;
                        for (i; i < itemsCount; i++) {
                            var first = '';
                            if (i == '0') {first = 'active'}
                            nav.append('<span data-swith=' + i + ' class=' + first + '></span>');
                        }
                        nav.find('[data-swith]').on('click',function (e) {
                            clearInterval(intervalID);
                            intervalID = setInterval(function(){
                                navigate('1','auto')
                            }, 5000)

                            var self = $(e.currentTarget),
                                id = self.attr('data-swith')
                            if (current == id) {
                                return
                            }
                            else {
                                navigate(id,'manual')
                            }
                        })
                    }

                    pagination();

                };
            }
        };
    }]);
    angularAMD.directive('swiperCarouselItem',function () {
        return {
            restrict: 'A',
            transclude: false,
            link: function (scope,element,attrs) {
                // wait for the last item in the ng-repeat then call init
                if (scope.$last) {
                    scope.initCarousel();
                }
            }
        };
    });
});
