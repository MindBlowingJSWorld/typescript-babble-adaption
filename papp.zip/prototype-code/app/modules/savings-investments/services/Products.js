define(['angularAMD'], function (angularAMD) {
    'use strict';

    var Products = function($http, $q) {
        var getList = function () {
            return $http.get('/savings/custodies').then (function(response) {

                var custodies = response.data.payload.accounts;

                var result = custodies.map(function(cur) {
                    return  {
                        "id": cur.id,
                        "name": cur.displayName,
                        "accountNb": cur.displayAccountNumber,
                        "available": cur.marketValue,
                        "freeToSpend": cur.marketValue,
                        "upcoming": cur.cashAmount,
                        "additional": {
                            "amount": "10000.00",
                            "elClassName": "yellow-bg"
                        },
                        "currency": cur.currency,
                        "pattern": 35,
                        "patternClassName": "green-bg",
                        "elClassName": "light-green-bg",
                        "savings": [
                            {
                                "id": "1",
                                "title": "Summer holiday",
                                "pattern": 45,
                                "amount": "500,00",
                                "elClassName": "light-blue-bg"
                            }
                        ]
                    }
                });

                return {data: {
                    "products":  result
                }}
            });
        };

        var getCorpList = function (params) {
            return $http.get(Path.fixture('corp/accounts'));
        };

        var searchProductTransactions = function(productId, json) {
            var l = json.length,
                i = -1,
                output = [],
                productData;

            while(++i <l) {
                productData = json[i];

                if (productData.id === productId) {
                    output = productData.transactions;
                }
            }

            return output;
        };

        var getTransactions = function(productId) {
            var deferred = $q.defer();

            $http.get(Path.fixture('transactions')).then(function(json) {
                deferred.resolve(searchProductTransactions(productId, json.data.history));
            });

            return deferred.promise;
        };

        return {
            getList: getList,
            getCorpList: getCorpList,
            getTransactions: getTransactions
        };
    };

    angularAMD.service('Products', Products);
    Products.$inject = ['$http', '$q'];
});
