define(['angularAMD'], function (angularAMD) {
    'use strict';

    var moduleName = 'savings-investments';

    angular
        .module('app.savingsInvestments', [])

        .config(['$stateProvider', function ($stateProvider) {

            $stateProvider
                .state('root.savingsInvestments', {
                    views: {
                        'main@root': angularAMD.route({
                            templateUrl: Path.view('savings-investments', moduleName)
                        })
                    }
                })
                .state('root.savingsInvestments.overview', {
                    url: '/savings-investment/overview',
                    views: {
                        'dashboard-content@root.savingsInvestments': angularAMD.route({
                            templateUrl: Path.view('overview', moduleName),
                            controller: 'SavingsInvestmentController',
                            controllerUrl: Path.controller('SavingsInvestmentController', moduleName)
                        }),
                        'messages@root.savingsInvestments.overview': angularAMD.route({
                            templateUrl: Path.view('messages', moduleName),
                            /*controller: 'MessagesController',
                            controllerUrl: Path.controller('MessagesController', moduleName)*/
                        }),
                        'moneytracker@root.savingsInvestments.overview': angularAMD.route({
                            templateUrl: Path.view('money-tracker', moduleName),
                            /*controller: 'MoneyTrackerController',
                            controllerUrl: Path.controller('MoneyTrackerController', moduleName)*/
                        })
                    },
                    resolve: {
                        productsList: ['Resolver', function(Resolver) {
                            return Resolver.get(Path.service('Products', moduleName), 'Products', 'getList');
                        }]
                        /*MessagesList: ['Resolver', function (Resolver) {
                            return Resolver.get(Path.service('Messages', moduleName), 'Messages', 'get');
                        }],
                        productsList: ['Resolver', function(Resolver) {
                            return Resolver.get(Path.service('Products', moduleName), 'Products', 'getList');
                        }]*/

                    }
                });

        }]);

});
