define(['app', 'velocity', 'Currency', 'accountNb', Path.directive('useSavings', 'savings-investments'), Path.directive('additionalFunds', 'savings-investments')], function (app) {
    'use strict';

    app.controller('SavingsInvestmentController', ['$scope', '$timeout', 'productsList', function ($scope, $timeout, productsList) {
        $scope.products = productsList.data.products;

        $timeout(function() {
            $scope.$broadcast('$productSelected', $scope.products[0]);
        });

        $scope.moneyBarItem = function(event, product) {
            var currentItem = $(event.target).closest('.single-item'),
                currentItemCollapsed = currentItem.find('.collapsed'),
                currentItemExpanded = currentItem.find('.expanded'),
                siblings = currentItem.siblings(),
                siblingsCollapsed = siblings.find('.collapsed'),
                siblingsExpanded = siblings.find('.expanded'),
                height1 = '156px',
                height2 = '55px',
                duration1 = 400;

            currentItemCollapsed
                .velocity({
                    height: '0',
                    paddingTop: '0'
                }, {duration: duration1});

            currentItemExpanded
                .velocity({
                    height: height1,
                    opacity: '1'
                }, {duration: duration1});

            siblingsCollapsed
                .velocity({
                    height: height2,
                    paddingTop: '5px'
                }, {duration: duration1});

            siblingsExpanded
                .velocity({
                    height: '0',
                    opacity: '0'
                }, {duration: duration1});

            currentItem.addClass('active');
            siblings.removeClass('active').find('.your-savings .dropdown').removeClass('active');

            $scope.$broadcast('$productSelected', product);
        };
    }]);

});
