define(['angularAMD'], function (angularAMD) {
    'use strict';

    angularAMD.service('Messages', ['$http', '$q', function ($http, $q) {

        var prepareMessages = function(messages) {
            return messages.map(function(message) {
                if (message.imgSmall) {
                    message.content = '<img src="'+ message.imgSmall +'" />';
                }

                return message;
            });
        };

        return {
            get: function () {
                var deferred = $q.defer(),
                    messagesUrl = Path.fixture('messages');

                $http
                    .get(messagesUrl)
                    .then(function (response) {
                        deferred.resolve(prepareMessages(response.data.messages));
                    });

                return deferred.promise;
            }
        };

    }]);

});
