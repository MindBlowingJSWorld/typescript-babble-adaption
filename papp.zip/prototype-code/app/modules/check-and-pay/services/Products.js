define(['angularAMD'], function (angularAMD) {
    'use strict';

    var Products = function($http, $q) {
        var getList = function () {
            return $http.get(Path.fixture('products'));
        };

        var getCorpList = function (params) {
            return $http.get(Path.fixture('corp/accounts'));
        };

        var searchProductTransactions = function(productId, json) {
            var l = json.length,
                i = -1,
                output = [],
                productData;

            while(++i <l) {
                productData = json[i];

                if (productData.id === productId) {
                    output = productData.transactions;
                }
            }

            return output;
        };

        var getTransactions = function(productId) {
            var deferred = $q.defer();

            $http.get(Path.fixture('transactions')).then(function(json) {
                deferred.resolve(searchProductTransactions(productId, json.data.history));
            });

            return deferred.promise;
        };

        return {
            getList: getList,
            getCorpList: getCorpList,
            getTransactions: getTransactions
        };
    };

    angularAMD.service('Products', Products);
    Products.$inject = ['$http', '$q'];
});
