define(['app'], function (app) {
    'use strict';

    var dropdown = function() {
        var link = function(scope, el) {
            var $dropdown = $(el),
                $container = $dropdown.closest('.dropdown-container'),
                $btn = $container.find('.arrow'),
                $ul = $dropdown.find('ul'),
                $li,
                marginTimeout;

            var getLiElements = function() {
                return $ul.find('li');
            };

            var activate = function() {
                var $tmpLi = getLiElements(),
                    liHeight = $tmpLi.outerHeight() * 0.85;

                $container.addClass('active');

                $tmpLi.each(function(i) {
                    var top = ((liHeight + 10) * i) + 'px',
                        delay = i * 30;

                    setTimeout(function () {
                        $tmpLi.eq(i).css('top', top);
	                    bindLi();
                    }, delay);
                });
            };

            var deactivate = function() {
                var $tmpLi = getLiElements(),
                    i,
                    l = $tmpLi.length,
                    resetTopPosition = function(nb) {
                        var delay = (nb - 1) * 50;

                        setTimeout(function() {
                            $tmpLi.eq(nb).css('top', 0);
                        }, delay);
                    };

                $tmpLi.removeClass('hover');
                $tmpLi.removeClass('margin');

                $container.removeClass('margin');
                $container.removeClass('active');

                for(i = l; i > 0; i--) {
                    resetTopPosition(i);
                }
            };

            var isActive = function() {
                return $container.hasClass('active');
            };

            var showDropdown = function() {
                if (isActive()) {
                    deactivate();
                } else {
                    activate();
                }
            };

            var documentClick = function(e) {
                var $target = $(e.target),
                    hideDropdown = isActive() && !($target.closest('.dropdown')).is($dropdown) && !$target.is($btn);

                if (hideDropdown) {
                    deactivate();
                }
            };

            var elementClick = function() {
                var $this = $(this),
                    $tmpLi,
                    repairZIndex = function() {
                        $tmpLi.each(function (i) {
                            $tmpLi.eq(i).css({
                                'z-index': 10 - i
                            });
                        });
                    };

                deactivate();

                $this.css({
                    'z-index': 11
                });

                setTimeout(function() {
                    $ul.prepend($this);
                    $tmpLi = getLiElements();

                    setTimeout(repairZIndex, 100);
                }, 300);
            };

	        function bindLi() {
		        $li = getLiElements();

		        $li.on('mouseenter',function () {
			        var $this = $(this);
			        if (!$this.is(':first-child')) {
				        clearTimeout(marginTimeout);
				        $container.addClass('margin');
				        $this.addClass('hover');
				        $this.nextAll().addClass('margin');
			        }
		        });

		        $li.on('mouseleave',function () {
			        var $this = $(this);

			        if (!$this.is(':first-child')) {
				        $this.removeClass('hover');
				        $this.nextAll().removeClass('margin');

				        marginTimeout = setTimeout(function () {
					        $container.removeClass('margin');
				        },400);
			        }
		        });

	        }

	        $dropdown.on('click', 'li:not(:first-child)', elementClick);
            $btn.on('click', showDropdown);
            $(document).on("click", documentClick);
        };

        var directive = {
            link: link,
            restrict: 'C'
        };

        return directive;
    };

    app.directive('dropdown', dropdown);
});
