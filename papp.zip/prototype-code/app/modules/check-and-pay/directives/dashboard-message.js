define(['app','velocity'], function (app) {
    'use strict';

    var dashboardMessage = function () {
        var link = function (scope, el) {
            var $el = $(el),
                thatImg,
                thatMessage,
                thatImgHeight;


            setTimeout(function(){
                function init() {
                    if ($el.hasClass('has-img')) {
                        thatImg = $el.find('.message-image');
                        thatMessage = $el.find('.message');

                            setTimeout(function() {
                                animateElement();
                            }, 1500);
                    }
	                $el.on('click',function(){
		                if ($el.hasClass('show-end')){
			                reverseAnimate();
		                }
	                });
                }

                init();
            }, 1000);

	        function reverseAnimate(){
		        if ($el.hasClass('show-end')){
			        $el.velocity({
				        opacity: 1
			        },{
				        duration: 50,
				        begin: function() {
					        $el.removeClass('show-end animated');
					        thatMessage.velocity({
						        opacity: 0
					        },{
						        'display':'none',
						        complete: function(){
							        thatMessage.removeClass('visible');
							        thatImg
								        .removeClass('show-continue');
							        $el
								        .css('height', thatImgHeight + 25);
							        animateElement();
						        }
					        });
				        }
			        });
		        }
	        }

            function animateElement() {
                var timeouts = [$el.find('[data-timer]').data('timer') * 1000, 500, 50],
                    i = 0,

                    messageDemo = [
                        function () {
                            timer();
                            thatImgHeight = thatImg.height('auto').height();
                            thatImg
                                .height(0)
                                .addClass('collapse')
                                .height(thatImgHeight);
                            $el.addClass('counter');
                        },

                        function () {
                            $el
                                .css('height', thatImgHeight + 25);
                            thatImg
                                .addClass('show-continue')
                                .removeClass('collapse')
                                .css('height', 0);
                            thatMessage
	                            .css({'opacity':'1','display':'inline-block'})
	                            .addClass('visible');
                            $el
                                .addClass('animated')
                                .css('height', thatMessage.height() + 10);
                        },

                        function () {
                            $el
                                .removeClass('counter')
                                .addClass('show-end');
                        }],
                    message = function () {
                        messageDemo[i]();
                        if (i < messageDemo.length - 1) {
                            setTimeout(message, timeouts[i]);
                        }
                        i++;
                    };

                message();
            }
        };

        function timer() {
            var timerItem = $('[data-timer]');
            timerItem.each(function () {
                var i = $(this).data('timer');
                timerItem.find('i').html(i);

                var interval = setInterval(function () {
                    i--;
	                timerItem.find('i').html(i);
                    if (i === 0) {
                        clearInterval(interval);
                        timerItem.find('i').html(i);
                    }
                }, 1000);
            });

        }



        var directive = {
            link: link,
            restrict: 'E',
            templateUrl: Path.view('directives/message', 'check-and-pay'),
            replace: true,
            scope: {
                message: '=data'
            }
        };

        return directive;
    };

    app.directive('dashboardMessage', dashboardMessage);
});