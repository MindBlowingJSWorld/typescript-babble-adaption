define(['app', 'fade', 'classMatch', Path.directive('dropdown', 'check-and-pay')], function (app) {
    'use strict';

    var savingId;

    var strToFloat = function(value) {
        return parseFloat(value.toString().replace(',', '.'));
    };

    var toInt = function(value) {
        return ~~value;
    };

    var roundTo = function(value, decimal){
        var to = decimal ? 10 : 100;
        return Math.round(value/to)*to;
    };

    var getStepValue = function(amount, stepsSize) {
        var v = amount / stepsSize;
        return (amount > 7000) ? roundTo(v) : (amount > 2000) ? roundTo(v, true) : v;
    };

    var useSavings = function($timeout, $rootScope) {
        var link = function(scope, el) {
            var $el = $(el),
                $item = $el.closest('.single-item'),
                $edit = $item.find('.edit'),
                $card = $edit.find('.card'),
                $destination = $edit.find('.destination'),
                $amount = $edit.find('.amount');


            var copyDataFromList = function() {
                var $active = $item.find('li:first'),
                    destination = $active.find('.destination').text(),
                    amount = $active.find('.amount').text();

                savingId = ~~$active.attr('data-id');

                $edit.find('.face').addClass($active.attr('data-bg'));
                $destination.text(destination);
                $amount.text(amount);
            };

            var flip = function() {
                $card.toggleClass('flipped');
            };

            scope.setEditStep = function(justOpened, makeFlip) {
                $edit.removeClass('loaded');
                $item.addClass('use-savings-step');

                if (scope.data.direction === 'TO') {
                    !makeFlip && $card.addClass('flipped');
                    $item.addClass('use-savings-step-to');
                    $item.removeClass('use-savings-step-from');
                } else {
                    $item.removeClass('use-savings-step-to');
                    $item.addClass('use-savings-step-from');
                }

                makeFlip && flip();
                justOpened && copyDataFromList();

                $timeout(function() {
                    $edit.addClass('active');
                }, 50);

                $timeout(function() {
                    $edit.addClass('loaded');
                }, 250);
            };

            scope.hideEditStep = function(finished) {
                if (finished) {

                } else {

                }
                $edit.removeClass('active');
                $edit.removeClass('loaded');

                $timeout(function() {
                    $card.removeClass('flipped');
                    $edit.find('.face').removeClassMatch('-bg');
                }, 350);
                $item.removeClass('use-savings-step');
                $item.removeClass('use-savings-step-to');
                $item.removeClass('use-savings-step-from');
            };
        };

        var ctrl = function($scope) {
            var updateAmount = function(amount1, amount2, from) {
                return from ? amount1 - amount2 : amount1 + amount2;
            };

            var updateSaving = function(amount) {
                var l =  $scope.product.savings.length,
                    i = -1,
                    saving, id, savingAmount;

                while(++i < l) {
                    saving = $scope.product.savings[i];
                    id = toInt(saving.id);

                    if (id === savingId) {
                        savingAmount = updateAmount(strToFloat(saving.amount), amount, $scope.data.direction === 'TO');
                        $timeout(function() {
                            $scope.product.savings[i].amount =  savingAmount;
                        });
                        break;
                    }
                }
            };

            var transfer = function() {
                var amount = toInt($scope.data.amount),
                    stepsSize = 50,
                    stepValue = getStepValue(amount, stepsSize),
                    available = strToFloat($scope.product.available),
                    i = 0,
                    isFrom = $scope.data.direction === 'FROM',
                    endAmount = updateAmount(available, amount, isFrom);

                while(++i < stepsSize) {
                    $timeout((function(i) {
                        return function() {
                            $scope.product.available = updateAmount(available, (stepValue * i), isFrom);
                        };
                    })(i), i * 20);
                }

                updateSaving(amount);

                $timeout(function() {
                    $scope.product.available = endAmount;
                }, ++i * 20);

                $timeout(function() {
                    $scope.product.pattern = Math.round($scope.product.upcoming * 100 / endAmount);
                });

                // UPCOMING

                $timeout(function() {
                    $rootScope.$broadcast('$showNotification', 'Transfer of '+ $scope.data.amount +' DKK from Saving Goal: Summer Holiday to ' + $scope.product.name + ' complete!');
                }, 1000);

                $scope.data.direction = null;
                $scope.data.amount = '';
                $scope.hideEditStep(true);
            };

            $scope.data = {
                direction: null,
                amount: ''
            };

            $scope.savingsSwitch = function(e, direction) {
                e.preventDefault();

                var justOpened = !$scope.data.direction;

                if ($scope.data.direction === direction) {
                    transfer();
                } else {
                    $scope.data.direction = direction;
                    $scope.setEditStep(justOpened);
                }
            };
	        $scope.checkWidth = function($event) {
		       var el = $event.currentTarget
		       var interval = setInterval(function(){
			       $(el).css({
				       width: getTextWidth($scope.data.amount, "normal 30px roboto") + 'px'
			       })
		       },10)
		        $(el).focusout(function(){
			         clearInterval(interval);
		        })
		        function getTextWidth (text, font) {
			        var canvas = getTextWidth.canvas || (getTextWidth.canvas = document.createElement("canvas"));
			        var context = canvas.getContext("2d");
			        context.font = font;
			        var metrics = context.measureText(text);
			        return metrics.width;
		        };
	        }

            $scope.closeUseSavingsStep = function(e) {
                if (e) {
                    e.preventDefault();
                }
                $scope.data.direction = null;
                $scope.data.amount = '';
                $scope.hideEditStep();
            };

            $scope.swap = function(e) {
                e.preventDefault();

                $scope.data.direction = $scope.data.direction === 'TO' ? 'FROM' : 'TO';
                $scope.setEditStep(false, true);
            };

            $scope.$on('$productSelected', function() {
                $scope.closeUseSavingsStep();
            });

        };
        ctrl.$inject = ['$scope'];

        var directive = {
            link: link,
            controller: ctrl,
            controllerAs: 'vm',
            restrict: 'E',
            replace: true,
            templateUrl: Path.view('directives/useSavings', 'check-and-pay'),
            scope: {
                product: '=product'
            }
        };

        return directive;
    };

    setTimeout(function(){
        $('.upcoming').each(function(){
            var that = $(this);
            var upcoming = $(this).find('b').text().replace(' ', '');
            var available = that.parents('.account-details').find('.amount').find('b').text().replace(' ', '');

            available = parseInt(available);
            upcoming = parseInt(upcoming);

            var percent = (upcoming / available) * 100;

            that.parents('.account-details').find('[data-pattern]').css('width', percent + '%');
        });
    },100);

    app.directive('useSavings', useSavings);
    useSavings.$inject = ['$timeout', '$rootScope'];
});
