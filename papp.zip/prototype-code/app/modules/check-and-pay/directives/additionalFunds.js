define(['app', 'fade'], function (app) {
    'use strict';

    var steps = {
        info: 'INFO',
        edit: 'EDIT',
        confirm: 'CONFIRMATION',
        final: 'FINALISATION',
        success: 'SUCCESS'
    };

    var toInt = function(value) {
        return parseInt(value, 10);
    };

    var roundTo = function(value, decimal){
        var to = decimal ? 10 : 100;
        return Math.round(value/to)*to;
    };

    var getStepValue = function(amount, stepsSize) {
        var v = amount / stepsSize;
        return (amount > 7000) ? roundTo(v) : (amount > 2000) ? roundTo(v, true) : v;
    };

    var additionalFunds = function($timeout, $rootScope) {
        var link = function(scope, el) {
            var $el = $(el),
                $content = $el.find('.content'),
                $item = $el.closest('.single-item'),
                $expanded = $item.find('.expanded'),
                $moneyBar = $('section.money-bar');

            var getFunds = function() {
                if (!$moneyBar.hasClass('additional-funds-step')) {
                    $moneyBar.height($moneyBar.outerHeight());
                    $expanded.height('auto');
                    scope.setStep(steps.edit);
                    $item.height('auto');
                    $moneyBar.addClass('step-animation');
                    $moneyBar.addClass('additional-funds-step');

                    $('.single-item').not($item).slideUp(250);

                    $el.onCSSTransitionEnd(function() {
                        $moneyBar.height('auto');
                    });

                    $timeout(function() {
                        $moneyBar.find('.edit-step').fadeIn(150);
                        $moneyBar.find('.interest-rate').fadeIn(150);
                    }, 150);
                }
            };

            var transfer = function() {
                var amount = ~~scope.data.amount,
                    stepsSize = 50,
                    stepValue = getStepValue(amount, stepsSize),
                    available = parseFloat(scope.product.available.toString().replace(',', '.')),
                    i = 0,
                    endAmount = available + amount;

                while(++i < stepsSize) {
                    $timeout((function(i) {
                        return function() {
                            scope.product.available = available + (stepValue * i);
                        };
                    })(i), i * 20);
                }

                $timeout(function() {
                    scope.product.available = endAmount;
                    scope.product.freeToSpend = toInt(scope.product.freeToSpend) + amount;
                }, ++i * 20);

                $timeout(function() {
                    scope.product.pattern = Math.round(scope.product.upcoming * 100 / endAmount);
                });

                $timeout(function() {
                    $rootScope.$broadcast('$showNotification', 'Transfer of '+ scope.data.amount +' DKK from Saving Goal: Summer Holiday to ' + scope.product.name + ' complete!');
                }, 1000);
            };

            var closeFundsStep = function(e, end) {
                e.preventDefault();
                e.stopPropagation();

                $moneyBar.height($moneyBar.outerHeight());
                $moneyBar.removeClass('additional-funds-step');
                $moneyBar.find('.edit-step').fadeOut(200);
                $moneyBar.find('.interest-rate').fadeOut(100);

                $('.single-item').not($item).slideDown(250);

                if (end) {
                    $item.addClass('additional-funds-finished');
                }

                $el.onCSSTransitionEnd(function() {
                    $moneyBar.height('auto');
                    $moneyBar.removeClass('step-animation');
                    scope.setStep(steps.info);

                    if (end) {
                        $content.addClass('additional-funds-finished');
                        transfer();
                    }
                });
            };

            var end = function(e) {
                closeFundsStep(e, true);
            };

            $content.on('click', getFunds);
            $content.on('click', '.close', closeFundsStep);
            $content.on('click', '.end', end);
        };

        var ctrl = function($scope) {
            var amount = parseInt($scope.product.additional.amount, 10);

            var formatYear = function(year) {
                if (toInt(year) === 1) {
                    return year + ' year';
                }
                return year + ' years';
            };

            var countPayment = function() {
                $scope.data.payment = ($scope.data.amount / (toInt($scope.data.year) * 12)).toFixed(2).toString().replace('.', ',');
                $scope.data.formattedYear = formatYear($scope.data.year);
            };

            $scope.data = {
                amount: amount,
                year: 5,
                formattedYear: formatYear(5)
            };

            $scope.$watch('[data.amount,data.year]', countPayment);

            $scope.active = steps.info;
            $scope.steps = steps;

            $scope.setStep = function(step, e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                $timeout(function() {
                    $scope.active = step;

                    if (step === steps.final) {
                        $timeout(function() {
                            $scope.active = steps.success;
                        }, 1000);
                    }
                });
            };

            $scope.interestDetails = false;
            $scope.showHideInterestDetails = function() {
                $scope.interestDetails = !$scope.interestDetails;
            };

        };
        ctrl.$inject = ['$scope'];

        var directive = {
            link: link,
            controller: ctrl,
            controllerAs: 'vm',
            restrict: 'E',
            replace: true,
            templateUrl: Path.view('directives/additionalFunds', 'check-and-pay'),
            scope: {
                product: '=product'
            }
        };

        return directive;
    };

    app.directive('additionalFunds', additionalFunds);
    additionalFunds.$inject = ['$timeout', '$rootScope'];
});
