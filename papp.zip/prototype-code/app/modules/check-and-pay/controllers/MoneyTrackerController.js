define(['app', Path.service('Products', 'check-and-pay')], function (app) {
    'use strict';

    var MoneyTrackerController = function($scope, $timeout, Products) {
        $scope.moneyTracker = [];

        $scope.getMoneyCssClass = function (value) {
            return parseInt(value, 10) > 0 ? 'money-in': 'money-out';
        };

        $scope.toggleMoneyTracker = function(event) {
            event.preventDefault();
            var target = $(event.currentTarget),
                targetWraper = target.parents('.collapsed'),
                expand = target.parents('.row-wrapper').find('.expand'),
                expandHeight = expand.height('auto').height();

            expand.css('height', '');

            expand.animate({
                opacity : 1,
                height: expandHeight + "px"
            }, 400);

            targetWraper.addClass('expanded');

            targetWraper.animate({
                height: '0px',
                padding: '0px',
                opacity: 0
            }, 400);
        };

        $scope.$on('$productSelected', function(e, product) {
            $scope.moneyTracker = [];
            $scope.product = product;
            Products.getTransactions(product.id).then(function(transactions) {
                $scope.moneyTracker = transactions;
            });
        });
    };

    app.controller('MoneyTrackerController', MoneyTrackerController);
    MoneyTrackerController.$inject = ['$scope', '$timeout', 'Products'];
});
