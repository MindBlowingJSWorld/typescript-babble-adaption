define(['app', 'modules/check-and-pay/directives/dashboard-message'], function (app) {
    'use strict';

    app.controller('MessagesController', ['$scope', 'MessagesList', function ($scope, MessagesList) {

        $scope.messages = angular.copy(MessagesList);
        $scope.maxMessagesViewAmount = 4;
        $scope.viewAllMessagesAnchVisible = $scope.messages.length > $scope.maxMessagesViewAmount;


    }]);

});
