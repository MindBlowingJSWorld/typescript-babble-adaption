define(['angularAMD'], function (angularAMD) {
    'use strict';

    var moduleName = 'check-and-pay';

    angular
        .module('app.checkAndPay', [])

        .config(['$stateProvider', function ($stateProvider) {

            $stateProvider
                .state('root.checkAndPay', {
                    abstract: true,
                    views: {
                        'main@root': angularAMD.route({
                            templateUrl: Path.view('check-and-pay', moduleName)
                        })
                    }
                })
                .state('root.checkAndPay.overview', {
                    url: '/check-and-pay/overview',
                    views: {
                        'dashboard-content@root.checkAndPay': angularAMD.route({
                            templateUrl: Path.view('overview', moduleName),
                            controller: 'CheckAndPayController',
                            controllerUrl: Path.controller('CheckAndPayController', moduleName)
                        }),
                        'messages@root.checkAndPay.overview': angularAMD.route({
                            templateUrl: Path.view('messages', moduleName),
                            controller: 'MessagesController',
                            controllerUrl: Path.controller('MessagesController', moduleName)
                        }),
                        'moneytracker@root.checkAndPay.overview': angularAMD.route({
                            templateUrl: Path.view('money-tracker', moduleName),
                            controller: 'MoneyTrackerController',
                            controllerUrl: Path.controller('MoneyTrackerController', moduleName)
                        })
                    },
                    resolve: {
                        MessagesList: ['Resolver', function (Resolver) {
                            return Resolver.get(Path.service('Messages', moduleName), 'Messages', 'get');
                        }],
                        productsList: ['Resolver', function(Resolver) {
                            return Resolver.get(Path.service('Products', moduleName), 'Products', 'getList');
                        }]
                    }
                })
                .state('root.checkAndPay.history', {
                    url: '/check-and-pay/history',
                    views: {
                        'dashboard-content@root.checkAndPay': angularAMD.route({
                            templateUrl: Path.view('history', moduleName),
                            controller: 'DashboardHistoryController',
                            controllerUrl: Path.controller('DashboardHistoryController', moduleName)
                        })
                    },
                    resolve: {
                        HistoryList: ['Resolver', function (Resolver) {
                            return Resolver.get(Path.service('History', moduleName), 'History', 'getDashboardList');
                        }]
                    }
                });

        }]);

});
