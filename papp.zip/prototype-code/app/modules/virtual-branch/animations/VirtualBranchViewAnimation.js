define(['angularAMD'], function (angularAMD) {
    'use strict';

    angularAMD.animation('.page-view', ['$rootScope', '$state', function($rootScope, $state) {
        var isVirtualBranchOnEnter = function() {
            return $state.is('root.virtual-branch') || $state.includes('root.virtual-branch');
        };

        var isVirtualBranchOnLeave = function() {
            return $rootScope.hasPreviousState && $rootScope.previousState.indexOf('root.virtual-branch') === 0;
        };

        var enter = function(el, doneFn) {
            var $el = $(el),
                $overlay = $el.find('.vb-overlay'),
                $avatars = $el.find('.avatars'),
                avatars = [$('#user-avatar').find('img').clone(), $('#talk-with-us').find('img').clone()],
                $backBtn = $el.find('.vb-back-btn'),
                $loader = $(document).find('.loader'),
                $overlayTitle = $(document).find('.overlay-title');

            avatars.forEach(function($img, i){
                var i = i+1,
                    $span = $('<span id="avatar-' + i + '"></span>');

                $span.append($img);
                $avatars.append($span);

                if($img.attr('title').length){
                    $img.after('<h2 id="avatar-title">' + $img.attr('title') + '</h2>');
                }
            });


            var $a1 = $avatars.find('#avatar-1'),
                $a2 = $avatars.find('#avatar-2');

            $overlay
                .velocity({
                    top: '-1600vw',
                    left: '-950vw',
                    height: '2000vw',
                    width: '2000vw',
                    borderRadius: '35%'
                }, {duration: 2000, complete: function(){
                    $backBtn.fadeIn();
                    $overlay
                        .velocity({
                            top: '0',
                            left: '0',
                            height: '100vh',
                            width: '100%',
                            borderRadius: '0'
                        }, {duration: 0, complete: function(){
                            doneFn();
                        }});
                }});

            $a1.velocity({
                width: '160px',
                height: '160px',
                top: '30vh',
                left: '400px'
            }, {duration: 800, complete: function(){
                $loader.fadeIn();
                $overlayTitle.fadeIn();
            }}, "easeInOut");

            $a2.velocity({
                width: '160px',
                height: '160px',
                top: '30vh',
                right: '400px'
            }, {duration: 800}, "easeInOut");
        };

        var leave = function(el, doneFn) {
            var $el = $(el),
                $overlay = $el.find('.vb-animate'),
                $backBtn = $el.find('.vb-back-btn');

            $backBtn.fadeOut(50, function() {
                $overlay
                    .velocity({
                        top: '100%',
                    }, {duration: 400, complete: function(){
                        $rootScope.clearClasses();
                        doneFn();
                    }});
            });
        };

        return {
            enter: function(element, doneFn) {
                if (isVirtualBranchOnEnter()) {
                    enter(element, doneFn);
                } else {
                    doneFn();
                }
            },

            leave: function(element, doneFn) {
                if (isVirtualBranchOnLeave()) {
                    leave(element, doneFn);
                } else {
                    doneFn();
                }
            }
        }

    }]);

});
