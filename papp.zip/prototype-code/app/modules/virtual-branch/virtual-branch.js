define(['angularAMD', Path.animation('VirtualBranchViewAnimation', 'virtual-branch')], function (angularAMD) {
    'use strict';

    angular
        .module('app.virtual-branch', [])
        .config(['$stateProvider', function ($stateProvider) {

            $stateProvider
                .state('root.virtual-branch', {
                    url: '/virtual-branch',
                    views: {
                        'main@root': angularAMD.route({
                            templateUrl: Path.view('start', 'virtual-branch'),
                            controller: 'TalkWithUsController',
                            controllerUrl: Path.controller('TalkWithUsController', 'virtual-branch')
                        })
                    }
                })
        }]);



});
