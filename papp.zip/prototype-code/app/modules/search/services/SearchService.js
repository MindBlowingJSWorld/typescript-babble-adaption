define(['angularAMD'], function (angularAMD) {
    'use strict';

    angularAMD.service('SearchService', ['$q', '$timeout', '$http', function($q, $timeout, $http) {
        var randomSort = function() {
            return Math.random() - 0.5;
        };

        var randomInt = function(min, max) {
            return Math.floor(Math.random() * (max - min)) + min;
        };

        var prepareJson = function(json) {
            var result = json.result.sort(randomSort),
                len = result.length;

            return result.slice(0, randomInt(len / 2, len))
        };

        var get = function(phrase) {
            var deferred = $q.defer(),
                params = {
                    phrase: phrase
                };

            $http
                .get(Path.fixture('search'), params)
                .then(function(json) {
                    deferred.resolve(prepareJson(json.data));
                });

            return deferred.promise;
        };

        return {
            get: get
        };
    }]);
});