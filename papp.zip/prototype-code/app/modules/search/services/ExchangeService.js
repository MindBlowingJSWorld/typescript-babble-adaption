define(['angularAMD'], function (angularAMD) {
    'use strict';

    angularAMD.service('ExchangeService', ['$http', function($http) {

        var get = function() {
            return $http.get(Path.fixture('exchange'));
        };

        return {
            get: get
        };
    }]);
});