define(['angularAMD', 'snap-svg'], function (angularAMD, snap) {
    'use strict';

    angularAMD.service('SearchAnimationService', [function() {
        var $document = $(document);

        var enter = function(doneFn) {
            var header = $document.find('#page-header'),
                wrapper = $document.find('#page-wrapper'),
                svg = $document.find("#svg-bg"),
                s = snap("#svg-bg"),
                newPath = s.path("M0 56.158V-.006h100V99.99l-49.984.002L0 99.994V56.158"),
                maxHeight = $(window).outerHeight() - 40;

            svg
                .css({
                    'display': 'block',
                    'height': '54px'
                })
                .animate({
                    height: maxHeight + 'px'
                });

            newPath
                .animate({ d:"M0 56.157V.002h100v99.98S83.334 92.09 50 92.09c-33.333 0-50 7.896-50 7.896v-43.83"}, 250, mina.easeinout, function(){
                    newPath
                        .animate({d:"M0 56.158V-.006h100V99.99l-49.984.002L0 99.994V56.158"}, 1500, mina.elastic);
                });

            doneFn();
        };

        var leave = function(doneFn) {
            var header = $document.find('#page-header'),
                wrapper = $document.find('#page-wrapper'),
                svg = header.find("#svg-bg"),
                s = snap("#svg-bg");

            svg.html('');

            var newPath = s.path("M0 30.892V.002h100V55s-16.666.002-50 .002H0v-24.11");

            svg
                .css({
                    'height': 'calc(190vh - 140px)'
                })
                .animate({
                    height: "108px"
                }, 700);

            doneFn();

            var pathAnimation = function () {
                newPath
                    .animate({d: "M0 30.892V.002h100V55S83.334 43 50 43C16.667 43 0 55.002 0 55.002v-24.11"}, 350, mina.easeinout, function () {
                        newPath.animate({d: "M0 30.892V.002h100V55s-16.666 9.5-50 9.5c-33.333 0-50-9.498-50-9.498v-24.11"}, 300, mina.easeinout, function () {
                            newPath.animate({d: "M0 30.892V.002h100V55s-16.666.002-50 .002H0v-24.11"}, 1500, mina.elastic );
                            header.removeClass('on-top');
                            svg.css({'display': 'none'});
                        });
                    });
            };

            setTimeout(pathAnimation, 300);
        };

        return {
            enter: enter,
            leave: leave
        };
    }]);
});