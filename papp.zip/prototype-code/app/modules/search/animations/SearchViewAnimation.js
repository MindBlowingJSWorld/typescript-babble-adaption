define(['angularAMD'], function (angularAMD) {
    'use strict';

    angularAMD.animation('.search-view', ['$rootScope', function($rootScope) {
        return {
            leave: function(element, doneFn) {
                if (element[0].children.length) {
                    $rootScope.clearClasses();
                }
                doneFn();
            }
        }
    }]);
});
