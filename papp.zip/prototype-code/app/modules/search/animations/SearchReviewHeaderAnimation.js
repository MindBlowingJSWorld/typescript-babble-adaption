define(['angularAMD', 'modules/search/services/SearchAnimationService'], function (angularAMD) {
    'use strict';

    angularAMD.animation('.expanded-review', ['SearchAnimationService', function(SearchAnimationService) {
        return {
            removeClass: function(element, className, doneFn) {
                SearchAnimationService.leave(doneFn);
            }
        }
    }]);

});
