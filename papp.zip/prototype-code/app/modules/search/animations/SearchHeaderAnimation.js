define(['angularAMD', 'modules/search/services/SearchAnimationService'], function (angularAMD) {
    'use strict';

    angularAMD.animation('.expanded', ['SearchAnimationService', function(SearchAnimationService) {
        return {
            addClass: function(element, className, doneFn) {
                SearchAnimationService.enter(doneFn);
            },

            removeClass: function(element, className, doneFn) {
                SearchAnimationService.leave(doneFn);
            }
        }
    }]);

});
