define([
    'angularAMD',
    'Resolver',
    Path.animation('SearchViewAnimation', 'search'),
    Path.animation('SearchHeaderAnimation', 'search'),
    Path.animation('SearchReviewHeaderAnimation', 'search')
], function (angularAMD) {
    'use strict';

    var exchangeRates = ['Resolver', function(Resolver) {
        return Resolver.get(Path.service('ExchangeService', 'search'), 'ExchangeService', 'get');
    }];

    angular
        .module('app.search', [])
        .config(['$stateProvider', function ($stateProvider) {

            $stateProvider
                .state('root.search', {
                    url: '/search',
                    views: {
                        'search@root': angularAMD.route({
                            templateUrl: Path.view('search', 'search'),
                            controller: 'SearchController',
                            controllerUrl: Path.controller('SearchController', 'search')
                        })
                    },
                    resolve: {
                        exchangeRates: exchangeRates
                    }
                })
                .state('root.search.review', {
                    url: '/review',
                    views: {
                        'search@root': angularAMD.route({
                            templateUrl: Path.view('search', 'search'),
                            controller: 'SearchReviewController',
                            controllerUrl: Path.controller('SearchReviewController', 'search')
                        })
                    },
                    resolve: {
                        exchangeRates: exchangeRates
                    }
                });

        }]);

});
