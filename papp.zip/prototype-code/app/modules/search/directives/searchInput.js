define(['app'], function (app) {
    'use strict';

    var QUERY_DELAY = 600;

    var searchInput = function ($timeout) {
        var link = function (scope, el) {
            var $el = $(el);

            var phraseChange = (function() {
                var timeout;

                return function(e) {
                    var phrase = e.target.value;

                    $timeout.cancel(timeout);
                    timeout = $timeout(function() {
                        scope.$emit('$searchInputChange', phrase);
                    }, QUERY_DELAY);
                };
            })();

            $el.on('input', phraseChange);
        };

        var directive = {
            link: link,
            restrict: 'A'
        };

        return directive;
    };

    app.directive('searchInput', searchInput);
    searchInput.$inject = ['$timeout'];
});