define(['app', 'accordion', 'modules/search/services/SearchService', 'modules/search/directives/searchInput'], function (app) {
    'use strict';

    app.controller('SearchController', ['$rootScope', '$scope', '$timeout', 'SearchService', 'exchangeRates', function ($rootScope, $scope, $timeout, SearchService, exchangeRates) {

        $timeout(function() {
            $rootScope.pageCssClass = 'page-search';
            $rootScope.headerCssClass = 'expanded';
        });

        var refreshResults = function(results) {
            $scope.results = results || [];
        };

        $scope.exchangeRates = exchangeRates.data.exchange;

        $scope.backButton = function(event) {
            $rootScope.backToPreviousState(event);
        };

        $scope.$on('$searchInputChange', function(e, phrase) {
            refreshResults();

            if (phrase) {
                SearchService.get(phrase).then(function(json) {
                    refreshResults(json);
                });
            }
        });

        refreshResults();
    }]);
});
