define(['app', 'snap-svg', 'velocity'], function (app, snap) {

    'use strict';

    app.controller('SearchReviewController', ['$rootScope', '$timeout', '$scope', '$state', 'exchangeRates', function ($rootScope, $timeout, $scope, $state, exchangeRates) {

        $rootScope.pageCssClass = 'page-search';
        $rootScope.headerCssClass = 'expanded-review';

        $scope.review = true;
        $scope.results = [
            {
                description: '<b>Buy</b> 300 EUR',
                action: {
                    desription: 'for 2 003,57 DKK',
                    name: 'buy'
                },
            }, {
                description: '<b>Sell</b> 300 EUR',
                action: {
                    desription: 'get 1 997,98 DKK',
                    name: 'sell'
                },
            }, {
                description: '<b>Open foreign currency account in</b> EUR'
            }, {
                description: '<b>Find</b> 300 EUR <b>in transaction history</b>'
            }, {
                description: '<b>Save</b> 300 EUR <b>on saving goal</b>'
            }, {
                description: '<b>Send</b> 300 EUR <b>to ...</b>'
            }, {
                description: '<b>Request</b> 300 EUR <b>from ...</b>'
            }, {
                description: '300 <b>point to achieve new badge</b>'
            }
        ];

        $scope.exchangeRates = exchangeRates.data.exchange;

        $scope.backButton = function(event) {
            $rootScope.backToPreviousState(event);
        };

        var sample = 'Search is the best way to find information',
            input = $( "#search-input" );

        function write(text, element, duration) {
            var stringLength = text.length,
                i = 0,
                random;

            if (typeof duration === 'undefined') {
                duration = 20;
            }

            function timeoutLoop() {
                element.val(element.val() + text.charAt(i));

                i++;
                if( i < stringLength ){
                    random = Math.floor((Math.random() * duration) + 20);
                    setTimeout( timeoutLoop, random );
                }
            }
            timeoutLoop();
        }

        var searchDemo = [
                function(){
                    write(sample, input, 8);
                },
                function() {
                    $('.cursor').addClass('animate');
                },
                function(){
                    input.val('');
                    $('.tip-v4').addClass('anim');
                    $('.search-field-wrapper').addClass('animate');
                },
                function() {
                    write('I want to buy 300 EUR', input, 10);
                },
                function(){
                    $('.search-autocomplete-block .results').slideDown();
                },
                function(){
                    $('[class^="tip-v"]').addClass('anim');
                },
                function(){
                    $('.cursor').css('top', '40px');
                },
                function(){
                    $('.search-autocomplete-block .results').slideUp();
                    input.val('');
                    input.attr('placeholder', sample);
                    $('.search-field-wrapper').removeClass('animate');
                    $('[class^="tip-v"]').fadeOut();
                },
                function(){
                    $('.cursor').fadeOut(function() {
                        $state.go('root.checkAndPay.overview');
                    });
                }
            ],

            timeouts = [1200, 1200, 800, 700, 800, 3000, 800, 600, 600],
            i = 0;


        function callFuncs() {
            searchDemo[i]();
            if (i < searchDemo.length - 1) {
                setTimeout(callFuncs, timeouts[i]);
            }
            i++;
        }

        setTimeout(callFuncs, 1000);
    }]);
});
