define(['app'], function (app) {
    'use strict';

    var controller = function(User) {
        var vm = this;

        var nav = {
            private: [
                {
                    name: 'Check & pay',
                    state: 'root.checkAndPay'
                }, {
                    name: 'Manage my finances',
                    state: 'root.savingsInvestments'
                }, {
                    name: 'Get advice & offer',
                    state: 'root.advice'
                }
            ],
            corp: [
                {
                    name: 'Money in & out',
                    state: 'root.corp.dashboard'
                }, {
                    name: 'Plan & forecast',
                    state: 'root.corp.plan'
                }, {
                    name: 'Portfolio',
                    state: 'root.corp.portfolio'
                }, {
                    name: 'Advice & offers',
                    state: 'root.corp.advice'
                }
            ]
        };

        vm.navigation = User.isPrivate() ? nav.private : nav.corp;
    };

    app.controller('NavigationController', controller);
    controller.$inject = ['User'];
});
