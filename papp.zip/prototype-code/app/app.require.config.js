var Path = (function() {
    var DS = '/';

    var getModulesPath = function(moduleName) {
        return (moduleName ? 'modules' + DS +  moduleName : 'components');
    };

    var filePath = function(fileType, fileName, moduleName) {
        return getModulesPath(moduleName) + DS + fileType + DS + fileName;
    };

    var fileTypesMap = {
        animation: 'animations',
        controller: 'controllers',
        directive: 'directives',
        factory: 'factories',
        filter: 'filters',
        service: 'services',
        vendor: 'vendor'
    };

    var output = {};

    output.module = function(moduleName) {
        return 'modules' + DS + moduleName + DS + moduleName;
    };

    output.fixture = function(path) {
        return 'app/fixtures' + DS + path + '.json';
    };

    output.view = function(fileName, moduleName) {
        return 'app' + DS + (moduleName ? getModulesPath(moduleName) + DS : '') + 'views' + DS + fileName + '.html';
    };

    Object.keys(fileTypesMap).forEach(function(type) {
        var dir = fileTypesMap[type];

        output[type] = function(fileName, moduleName) {
            return filePath(dir, fileName, moduleName);
        };
    });

    return output;
})();


(function() {
    var app = '../app/',
        vendorPath = '../assets/js/vendor/';

    require.config({
        paths: {
            'angularAMD': vendorPath + 'angularAMD',
            'ngload': vendorPath + 'ngload',
            'velocity': vendorPath + 'velocity',
            'velocity-ui': vendorPath + 'velocity.ui',
            'velocity-ui-angular': vendorPath + 'velocity.ui.angular',
            'on-css-animation-end': 'components/vendor/jquery.oncssanimationend',
            'jquery-resize': 'components/vendor/jquery.ba-resize',
            'classMatch': 'components/vendor/classMatch',
            'modernizr': 'components/vendor/modernizr.custom',
            'snap-svg': vendorPath + 'snap.svg',

            'app': 'app',

            'CheckAndPay': Path.module('check-and-pay'),
            'SavingsInvestment': Path.module('savings-investments'),
            'Messages': Path.service('Messages', 'check-and-pay'),
            'History': Path.service('History', 'check-and-pay'),
            'MoneyTracker': Path.service('MoneyTracker', 'check-and-pay'),

            'Corp': Path.module('corp'),

            'Authorization': Path.module('authorization'),
            'Authentication': Path.service('AuthenticationService', 'authorization'),

            'VirtualBranch': Path.module('virtual-branch'),
            'Search': Path.module('search'),

            'Resolver': Path.service('Resolver'),
            'User': Path.service('User'),

            'accountNb': Path.filter('accountNb'),
            'CustomCurrency': Path.filter('customCurrency'),
            'Currency': Path.directive('currency'),
            'preventDefault': Path.directive('preventDefault'),
            'tabs': Path.directive('tabs'),
            'notifications': Path.directive('notifications'),

            'content-slide': Path.animation('content-slide'),
            'accordion': Path.animation('accordion'),
            'fade': Path.animation('fade'),
            'fadeSlide': Path.animation('fadeSlide'),
            'fadeInOut': Path.animation('fadeInOut')
        },

        shim: {
            'ngload': ['angularAMD'],
            'velocity-ui': ['velocity'],
            'velocity-ui-angular': ['velocity-ui']
        },

        deps: ['app']

    });
})();