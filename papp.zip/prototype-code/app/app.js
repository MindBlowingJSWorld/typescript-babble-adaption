(function() {
    var requireDependencies = [
            'angularAMD',
            'velocity-ui-angular',
            'on-css-animation-end',

            // modules
            'CheckAndPay',
            'SavingsInvestment',
            'Authorization',
            'VirtualBranch',
            'Search',
            'Corp',

            // services
            'User',

            // directives
            'notifications',
            'preventDefault',
            'tabs',

            // animations
            'content-slide',
            'accordion',
            'fade',
            'fadeSlide',
            'fadeInOut'
        ],
        vendorModules = [
            'ui.router',
            'ngResource',
            'ngMessages',
            'ngMaterial',
            'ngCookies',
            'ngSanitize',
            'velocity.ui',
            'ngAnimate'
        ],
        appModules = [
            'app.checkAndPay',
            'app.savingsInvestments',
            'app.authorization',
            'app.virtual-branch',
            'app.search',
            'app.corp'
        ];


    define(requireDependencies, function (angularAMD) {
        'use strict';

        var modules = vendorModules.concat(appModules),
            app = angular.module('app', modules);

        app
            .config(['$stateProvider', '$urlRouterProvider',
                function ($stateProvider, $urlRouterProvider) {

                    $stateProvider
                        .state('root', {
                            abstract: true,
                            views: {
                                'root': angularAMD.route({
                                    templateUrl: Path.view('root'),
                                    controller: 'RootController',
                                    controllerUrl: Path.controller('RootController')
                                }),
                                'header@root': angularAMD.route({
                                    templateUrl: Path.view('header')
                                }),
                                'navigation@root': angularAMD.route({
                                    templateUrl: Path.view('navigation', 'navigation'),
                                    controller: 'NavigationController',
                                    controllerAs: 'vm',
                                    controllerUrl: Path.controller('NavigationController', 'navigation')
                                }),
                                'userinfo@root': angularAMD.route({
                                    templateUrl: Path.view('user-info', 'user-info'),
                                    controller: 'UserInfoController',
                                    controllerUrl: Path.controller('UserInfoController', 'user-info')
                                })
                            }
                        })
                        .state('authorization', {
                            abstract: true,
                            views: {
                                'authorization': angularAMD.route({
                                    templateUrl: Path.view('authorization')
                                })
                            }
                        });

                    // resolves "Error: $rootScope:infdig Infinite $digest Loop"
                    $urlRouterProvider.otherwise(function ($injector) {
                        var $state = $injector.get("$state");
                        $state.go('root.checkAndPay.overview');
                    });
                }
            ])

            .run(['$log', '$cookies', '$rootScope', '$state', '$timeout', 'User', function ($log, $cookies, $rootScope, $state, $timeout, User) {
                $('.preloader').remove();
                $timeout(function () {
                    $('body').removeClass('loading');
                }, 300);

                $log.info('APP: Demo App instantiated properly.');
                $log.info('AUTHENTICATION: For logging in, please use following data:\n Login: tobias\n Pin: 1111.');

                $rootScope.$on('$stateChangeStart', function (event, next) {
                    var isLogged = User.isSignedIn();

                    if (!isLogged && next.name !== 'authorization.logIn' && next.name !== 'authorization.loggedOut') {
                        event.preventDefault();
                        $state.go('authorization.logIn');
                    }
                });

            }]);

        return angularAMD.bootstrap(app);
    });
})();
